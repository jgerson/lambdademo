exports.handler = function(event, context) {
    context.done(null, 'Hello from Lambda');
};